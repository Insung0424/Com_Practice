package com.JIS.upgradeProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpgradeProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpgradeProjectApplication.class, args);
	}

}
